<!--
=========================================================
 Light Bootstrap Dashboard - v2.0.1
=========================================================

 Product Page: https://www.creative-tim.com/product/light-bootstrap-dashboard
 Copyright 2019 Creative Tim (https://www.creative-tim.com)
 Licensed under MIT (https://github.com/creativetimofficial/light-bootstrap-dashboard/blob/master/LICENSE)

 Coded by Creative Tim

=========================================================

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::to('/')); ?>/assets/img/icon_i2.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title><?php echo e('leave'); ?></title>
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::to('/')); ?>/img/imgback/icon1.jpg" />
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href="<?php echo e(URL::to('/')); ?>/assets2/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="<?php echo e(URL::to('/')); ?>/assets2/css/demo.css" rel="stylesheet" />
</head>

<body>

            <style>
                        h1 {
                            color: Black;
                            text-align: center;
                            font-size: 200%;
                            

                        }
                        label {
                            color: Black;
                            text-align: center;
                        }
            </style>
    <div class="wrapper">
        <div class="sidebar" data-image="assets2/img/sidebar-4.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="sidebar-wrapper">
                <div class="logo">
                    <a  class="simple-text">
                    Leaveth.com
                    </a>
                </div>
                <ul class="nav">
                    <li>
                        <a class="nav-link" href="VH">
                            <i class="nc-icon nc-circle-09"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="tablepe">
                            <i class="nc-icon nc-notes"></i>
                            <p>Time List</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="leave3">
                            <i class="nc-icon nc-bell-55"></i>
                            <p>ผลการอนุมัติลา</p>
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="leave2">
                            <i class="nc-icon nc-align-left-2"></i>
                            <p>การขออนุมัติลา</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="timestampch">
                            <i class="nc-icon nc-tap-01"></i>
                            <p>บันทึกเวลา</p>
                        </a>
                    </li>
                  </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#pablo">การขออนุมัติลา </a>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e('logout'); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card strpied-tabled-with-hover">
                                <div class="card-header ">
                                    <h4 class="card-title">การขออนุมัติลา</h4>
                                    <p class="card-category">การขออนุมัติลา</p>
                                </div>
                                <div class="card-body table-full-width table-responsive">
                                    <table class="table table-hover table-striped">
                                        <tbody>
                                        <form  method="POST" action="<?php echo e('letter'); ?>"  enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="container">
                                                <div class="row">
                                                        <div class="col-md">
                                                        </div>
                                                    <div class="col-md">
                                                        <h1  align = 'center'>ใบลา</h1>
                                                    </div>
                                                    <div class="col-md">
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="container">
                                            <div class="row">
                                                <div class="col-md-6 pr-1">
                                                <div class="form-group row">
                                                    <label for="text"  class="col-md-2 col-form-label">เรื่อง</label>
                                                    <div class="col-md-10 pr-1">
                                                    <input type="text" class="form-control"   name="affair" id="affair" placeholder="affair" required autocomplete="affair" autofocus>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col-md-2 pr-1"></div>
                                                <div class="col-md-2 pr-1">
                                                </div>
                                                <div class="col-md-2 pr-1">
                                                </div>
                                                <div class="col-md-6 pr-1">
                                                <div class="form-group row">
                                                    <label for="text" class="col-md-2 col-form-label">เรียน</label>
                                                    <div class="col-md-10 pr-1">
                                                    <select class="form-control" name="head">
                                                            <?php $__currentLoopData = $boss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boss1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($boss1->idchief); ?>"><?php echo e($boss1->fname); ?>&nbsp;&nbsp;<?php echo e($boss1->lname); ?>&nbsp;&nbsp;&nbsp;(<?php echo e($boss1->niname); ?>)</option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </select>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col-md-2 pr-1">
                                                </div>
                                                <div class="col-md-2 pr-1">
                                                </div>
                                                <div class="col-md-2 pr-1">
                                                </div>
                                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row">
                                                <div class="col-md-4 pr-1">
                                                <div class="form-group row">
                                                    <label for="text" class="col-sm-3 col-form-label">ชื่อ</label>
                                                    <div class="col-md-8 pr-1">
                                                    <input class="form-control" type="text" value="<?php echo e($ticket->firstnamebem); ?>" id="example-date-input" name="lea_fname" >
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col md-4 pr-1">
                                                <div class="form-group row">
                                                    <label for="text" class="col-md-3 pr-1 col-form-label">นามสกลุ</label>
                                                    <div class="col-md-8 pr-1">
                                                    <input class="form-control" type="text" value="<?php echo e($ticket->lastnamebem); ?>" id="example-date-input" name="lea_lname" >
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col-md-4 pr">
                                                <div class="form-group row">
                                                    <label for="text" class="col-md-3 pr-1 col-form-label">ชื่อเล่น</label>
                                                    <div class="col-md-6 pr-1">
                                                    <input class="form-control" type="text" value="<?php echo e($ticket->nickname); ?>" id="example-date-input" name="lea_niname" >
                                                    </div>
                                                  </div>
                                                 </div>
                                              </div>
                                              </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row">
                                                <div class="col-md-6 pr-1">
                                                <div class="form-group row">
                                                    <label for="text" class="col-sm-2 col-form-label">ตำเเหน่ง</label>
                                                    <div class="col-md-8 pr-1">
                                                    <select class="form-control" name="position">
                                                            <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticketp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option><?php echo e($ticketp->position); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </select>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col-md-6 pr-1">
                                                <div class="form-group row">
                                                    <label for="text" class="col-sm-2 col-form-label">ขอลา</label>
                                                    <div class="col-md-8 pr-1">
                                                      <select class="form-control" name="leave">
                                                            <?php $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticketl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option><?php echo e($ticketl->sickleave); ?></option>
                                                                <option><?php echo e($ticketl->personalleave); ?></option>
                                                                <option><?php echo e($ticketl->vacationleave); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </select>
                                                    </div>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12 pr-1">
                                                    <div class="form-group row">
                                                        <label for="text" class="col-sm-2 col-form-label">เนื่องจาก</label>
                                                            <div class="col-md-8 pr-1">
                                                            <input type="text" class="form-control"  name="since" id="text" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4 pr-1">
                                                <div class="form-group row">
                                                    <label for="text" class="col-sm-3 col-form-label">นับตั้งเเต่</label>
                                                    <div class="col-md-8 pr-1">
                                                    <input class="form-control" type="date" value="วว/ดด/ปป" id="example-date-input" name="date1"  required>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col md-4 pr-1">
                                                <div class="form-group row">
                                                    <label for="text" class="col-md-3 pr-1 col-form-label">ถึงวันที่</label>
                                                    <div class="col-md-8 pr-1">
                                                    <input class="form-control" type="date" value="วว/ดด/ปป" id="example-date-input" name="date2" required>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col-md-4 pr">
                                                <div class="form-group row">
                                                    <label for="text" class="col-md-3 pr-1 col-form-label">มีกำหนด</label>
                                                    <div class="col-md-6 pr-1">
                                                        <input type="text" class="form-control" name="da" id="da" required>
                                                    </div>
                                                    <label for="text" class="col-md- pr-1 col-form-label">วัน</label>
                                                  </div>
                                                 </div>
                                              </div>
                                              <div class="row">
                                                <div class="col-md-6 pr-1">
                                                <div class="form-group row">
                                                    <label for="text" class="col-md-4 pr-1 col-form-label">ในระหว่างลาสมารถติดต่อข้าพเจ้าได้ที่</label>
                                                    <div class="col-md-8 pr-1">
                                                    <input type="text" class="form-control" name="address" id="address" placeholder="Address">
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col-md-6 pr-1">
                                                <div class="form-group row">
                                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label for="text" class="col-md-2 pr-1 col-form-label">เบอร์ติดต่อ</label>
                                                    <div class="col-md-6 pr-1">
                                                    <input type="text" class="form-control" name="tel" value="<?php echo e($ticket->tel); ?>" id="tel">
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 pr-1">
                                                </div>
                                                <div class="col-md- pr-1">
                                                <div class="form-group">
                                                <input type="file" class="form-control" id="image"  name="image">
                                                </div>
                                                </div>
                                                <div class="col-md-2 pr-1">
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-info btn-fill pull-right">create Profile</button>
                                        </form>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav>
                        <ul class="footer-menu">
                            <li>
                                <a href="#">
                                    Home
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Company
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Portfolio
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Blog
                                </a>
                            </li>
                        </ul>
                        <p class="copyright text-center">
                            ©
                            <script>
                                document.write(new Date().getFullYear())
                            </script>
                            <a href="http://www.creative-tim.com">Creative Tim</a>, made with love for a better web
                        </p>
                    </nav>
                </div>
            </footer>
        </div>
    </div>
    <!--   -->
</body>
<!--   Core JS Files   -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</html>
<?php /**PATH C:\xampp\htdocs\project\leave\resources\views/personnel/leave2.blade.php ENDPATH**/ ?>